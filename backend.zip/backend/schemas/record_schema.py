# Investment record schema
