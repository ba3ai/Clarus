# ROI, balance, profit logic
