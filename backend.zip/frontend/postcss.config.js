module.exports = {
  plugins: {
    tailwindcss: {},       // ✅ correct built-in plugin name
    autoprefixer: {},      // ✅ still needed
  },
};
