// Charts for visualization
